<!-- 핫리로딩 -->

https://github.com/pmmmwh/react-refresh-webpack-plugin

웹팩 데브 서버를 쓰면 얻는 이점은 무엇인가?
일반 리로딩과 핫 리로딩의 차이점은?

1. 리로딩은 새로고침
2. 핫 리로딩은 기존 데이터 유지하되 변경된 데이터만 바꿔줌. 즉 리로딩이 돼도 데이터가 안날아감
3. 근데 React cra때 데이터 날아간거 본적이 없는데?
4. 아마 내 생각에 CRA에는 기본으로 핫리로딩이 탑재되어 있을 것으로 추측됨.

Require는 node의 모듈시스템

<!-- 타입스크립트 문제  참조-->

https://github.com/contentful/contentful-management.js/issues/848
