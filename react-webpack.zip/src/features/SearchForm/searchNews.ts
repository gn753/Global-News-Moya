import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const searchApi = createApi({
  reducerPath: "searchApi",
  baseQuery: fetchBaseQuery({ baseUrl: "http://54.180.136.0:3000" }),
  endpoints: (builder) => ({
    getNewsListData: builder.query<any, string>({
      query: (test:any) => ({
        url:`/search`,
        params:test
      }),
    }),
  }),
});
