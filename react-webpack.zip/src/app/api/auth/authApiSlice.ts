import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const newsSearchApi = createApi({
  reducerPath: "newsSearchApi",
  baseQuery: fetchBaseQuery({ baseUrl: "/master/" }),
  endpoints: (builder) => ({
    getNewsKeyWordList: builder.query<any, string>({
      query: (name) => `pokemon/${name}`,
    }),
  }),
});
