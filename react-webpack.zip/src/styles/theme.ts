export const theme = {
  primaryColor: "#48C0B7",
  blueGreenColor: "#144056",
  textDefault: "#000",
  newsTitle: "#1D1D1D",
  myKeyword: "#3B788B",
  subTitle: "#2D2D2D",
  overLine: "#E1E1E1",
  newsDescription: "#7A7A7A"
};
