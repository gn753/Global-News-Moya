import React, { ReactChildren, ReactChild } from "react";
import styled from "@emotion/styled";
import GlobalHeader from "@src/layout/header/index";
import GlobalFooter from "@src/layout/footer/index";

interface AuxProps {
  children: ReactChild | ReactChildren;
}

export const Layout: React.FC<AuxProps> = (props) => {
  // const location = useLocation<LocationTypes>();
  // const path = location.pathname.slice(1);

  // if (path === "login") return <Root>{props.children}</Root>;

  return (
    <Root className="layout">
      <GlobalHeader />
      {props.children}
      <GlobalFooter />
    </Root>
  );
};

export const Root = styled.div`
  display: flex;
  flex-direction: column;
  position: relative;
`;
