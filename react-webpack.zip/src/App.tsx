import { BrowserRouter, Route, Routes } from "react-router-dom";
import React from "react";
import ExamplePage from "@src/pages/ExamplePage";
import "@src/examplePage.scss";

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<ExamplePage />} />
      </Routes>
    </BrowserRouter>
  );
};
export default App;
